﻿#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define N 10
int main()
{
	printf("Author: Sofroni Petkov Nenov FN:361222020 \n");//author
	printf("Task: \n");
	printf(" * make an array A with 100 numbers between -1000 and 1000 \n");
	printf(" * if an element from A and an element from B with the same position has a even sum in interval from K to L \n");
	printf("   then the element from A should be made into a zero! \n");
	printf(" * Counts the amount of elements that were changed \n");
	int num, sum = 0, A[N][N], B[N][N];
	int i = 0, j = 0, K=0, L=0,count=0;
	printf("\n Enter  100 numbers between -1000 and 1000 ! ");
	for (; i < N; i++) {
		for (; j < N; j++) {
			do {
				printf("\n A[%d][%d] = ",i,j);
				scanf_s("%d", &num);
				if (num < -1000 || num > 1000) { printf("\n Try again!"); }
			} while (num < -1000 || num > 1000);
			A[i][j] = num;
		}
		j = 0;
	}
	j = 0;
	i = 0;
	srand(time(0));
	for (; i < N; i++) {
		for (; j < N; j++) {
			B[i][j] = rand() % 2000 - 1000;
		}
		j = 0;
	}
	j = 0;
	i = 0;
	printf("\n Matrix A: \n");
	for (; i < N; i++){
		for (; j < N; j++)
		{
			printf(" %d",A[i][j]);
		}
		printf("\n");
		j = 0;
	}
	i = 0;
	j = 0;
	printf("\n Matrix B: \n");
	for (; i < N; i++) {
		for (; j < N; j++)
		{
			printf(" %d", B[i][j]);
		}
		j = 0;
		printf("\n");
	}
	i = 0;
	j = 0;
	printf("\n Enter K: ");
	scanf_s("%d", &K);
	printf("\n Enter L: ");
	scanf_s("%d", &L);
	for (; i < N; i++) {
		for (; j < N; j++) {
			sum = A[i][j] + B[i][j];
			if(sum%2==0)
			{
				if (sum <= L && sum >= K) { A[i][j] = 0; count++; }
			}
			sum = 0;
		}
		j = 0;
	}
	i = 0;
	j = 0;
	printf("\n Matrix A after changes : \n");
	for (; i < N; i++) {
		for (; j < N; j++)
		{
			printf(" %d", A[i][j]);
		}
		j = 0;
		printf("\n");
	}
	printf("\n The count of changes in A is : %d \n", count);
	system("pause");
	return 0;
}